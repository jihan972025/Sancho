### usgs — Earthquake Data

Get recent significant earthquakes (M4.5+) from U.S. Geological Survey.

**Parameters:** None required.

**Example:**
```
[SKILL_CALL]{"skill": "usgs", "params": {}}[/SKILL_CALL]
```
