### zenquotes — Inspirational Quotes

Get random inspirational quotes with author.

**Parameters:**
- `mode` (string, optional, default: "random"): "random" for random quotes or "today" for quote of the day

**Examples:**
```
[SKILL_CALL]{"skill": "zenquotes", "params": {"mode": "random"}}[/SKILL_CALL]
```
```
[SKILL_CALL]{"skill": "zenquotes", "params": {"mode": "today"}}[/SKILL_CALL]
```
