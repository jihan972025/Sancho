"use strict";
/**
 * Cloudflare Quick Tunnel manager.
 *
 * Spawns `cloudflared tunnel --url http://localhost:8765` to create a public
 * HTTPS URL that proxies traffic to the local FastAPI backend.
 * No Cloudflare account or API key is required (Quick Tunnel mode).
 *
 * If cloudflared is not installed, it is automatically downloaded from
 * GitHub releases on first use (~30 MB).
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startTunnel = startTunnel;
exports.stopTunnel = stopTunnel;
exports.getTunnelUrl = getTunnelUrl;
const child_process_1 = require("child_process");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const https_1 = __importDefault(require("https"));
const electron_1 = require("electron");
let tunnelProcess = null;
let tunnelUrl = '';
const isDev = !electron_1.app.isPackaged;
const CLOUDFLARED_DOWNLOAD_URL = 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe';
// ── Helpers ────────────────────────────────────────────────────────
/**
 * Download a file via HTTPS, following redirects (GitHub → S3).
 */
function downloadFile(url, dest, maxRedirects = 5) {
    return new Promise((resolve, reject) => {
        if (maxRedirects <= 0) {
            return reject(new Error('Too many redirects'));
        }
        const tmpDest = dest + '.tmp';
        https_1.default.get(url, (res) => {
            // Follow redirects (301, 302, 303, 307, 308)
            if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                console.log(`[Tunnel] Redirect ${res.statusCode} → ${res.headers.location.slice(0, 80)}...`);
                res.resume();
                return downloadFile(res.headers.location, dest, maxRedirects - 1)
                    .then(resolve)
                    .catch(reject);
            }
            if (res.statusCode !== 200) {
                res.resume();
                return reject(new Error(`Download failed: HTTP ${res.statusCode}`));
            }
            const totalBytes = parseInt(res.headers['content-length'] || '0', 10);
            let downloadedBytes = 0;
            let lastLogPct = -10;
            const file = fs_1.default.createWriteStream(tmpDest);
            res.on('data', (chunk) => {
                downloadedBytes += chunk.length;
                if (totalBytes > 0) {
                    const pct = Math.round((downloadedBytes / totalBytes) * 100);
                    if (pct >= lastLogPct + 10) {
                        lastLogPct = pct;
                        console.log(`[Tunnel] Downloading cloudflared... ${pct}% (${Math.round(downloadedBytes / 1024 / 1024)}MB / ${Math.round(totalBytes / 1024 / 1024)}MB)`);
                    }
                }
            });
            res.pipe(file);
            file.on('finish', () => {
                file.close(() => {
                    try {
                        if (fs_1.default.existsSync(dest))
                            fs_1.default.unlinkSync(dest);
                        fs_1.default.renameSync(tmpDest, dest);
                        resolve();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            });
            file.on('error', (err) => {
                try {
                    fs_1.default.unlinkSync(tmpDest);
                }
                catch { /* ignore */ }
                reject(err);
            });
        }).on('error', (err) => {
            reject(err);
        });
    });
}
/**
 * Locate the cloudflared binary.
 * - Production: bundled in extraResources/cloudflared/
 * - Dev: check ~/.sancho/cloudflared.exe
 */
function findCloudflared() {
    if (!isDev) {
        const bundled = path_1.default.join(process.resourcesPath, 'cloudflared', 'cloudflared.exe');
        if (fs_1.default.existsSync(bundled))
            return bundled;
    }
    const homeDir = process.env.USERPROFILE || process.env.HOME || '';
    const localBin = path_1.default.join(homeDir, '.sancho', 'cloudflared.exe');
    if (fs_1.default.existsSync(localBin))
        return localBin;
    // Last resort: assume it's on PATH
    return 'cloudflared';
}
/**
 * Ensure cloudflared binary exists, downloading if necessary.
 */
async function ensureCloudflared() {
    // Production: check bundled binary
    if (!isDev) {
        const bundled = path_1.default.join(process.resourcesPath, 'cloudflared', 'cloudflared.exe');
        if (fs_1.default.existsSync(bundled))
            return;
    }
    // Check ~/.sancho/cloudflared.exe
    const homeDir = process.env.USERPROFILE || process.env.HOME || '';
    const sanchoDir = path_1.default.join(homeDir, '.sancho');
    const localBin = path_1.default.join(sanchoDir, 'cloudflared.exe');
    if (fs_1.default.existsSync(localBin))
        return;
    // Not found anywhere — download from GitHub
    console.log('[Tunnel] cloudflared not found, downloading from GitHub...');
    if (!fs_1.default.existsSync(sanchoDir)) {
        fs_1.default.mkdirSync(sanchoDir, { recursive: true });
    }
    await downloadFile(CLOUDFLARED_DOWNLOAD_URL, localBin);
    console.log(`[Tunnel] cloudflared downloaded to ${localBin}`);
}
/**
 * Notify the Python backend of the active tunnel URL.
 */
async function notifyBackend(url) {
    try {
        const http = await Promise.resolve().then(() => __importStar(require('http')));
        await new Promise((resolve, reject) => {
            const body = JSON.stringify({ url });
            const req = http.request('http://127.0.0.1:8765/api/voice/tunnel-url', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(body),
                },
            }, (res) => {
                res.on('data', () => { });
                res.on('end', () => resolve());
                res.on('error', reject);
            });
            req.on('error', reject);
            req.write(body);
            req.end();
        });
        console.log(`[Tunnel] Notified backend: ${url || '(cleared)'}`);
    }
    catch (err) {
        console.error('[Tunnel] Failed to notify backend:', err.message);
    }
}
// ── Public API ─────────────────────────────────────────────────────
/**
 * Start the cloudflared tunnel.
 * Downloads cloudflared automatically if not found.
 * Returns the public HTTPS URL once the tunnel is ready.
 */
async function startTunnel() {
    // Already running
    if (tunnelProcess && tunnelUrl)
        return tunnelUrl;
    // Kill any stale process
    if (tunnelProcess) {
        tunnelProcess.kill();
        tunnelProcess = null;
        tunnelUrl = '';
    }
    // Ensure binary exists (auto-download if needed)
    await ensureCloudflared();
    const bin = findCloudflared();
    console.log(`[Tunnel] Starting: ${bin} tunnel --url http://localhost:8765`);
    return new Promise((resolve, reject) => {
        const proc = (0, child_process_1.spawn)(bin, ['tunnel', '--url', 'http://localhost:8765'], {
            stdio: ['pipe', 'pipe', 'pipe'],
            windowsHide: true,
        });
        tunnelProcess = proc;
        // URL pattern from cloudflared output
        const urlRegex = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/;
        let resolved = false;
        // Timeout: if URL not found in 30s, reject
        const timeout = setTimeout(() => {
            if (!resolved) {
                resolved = true;
                reject(new Error('Tunnel startup timed out (30s)'));
            }
        }, 30000);
        const handleData = (data) => {
            const text = data.toString();
            console.log(`[Tunnel] ${text.trim()}`);
            if (!resolved) {
                const match = text.match(urlRegex);
                if (match) {
                    resolved = true;
                    clearTimeout(timeout);
                    tunnelUrl = match[0];
                    console.log(`[Tunnel] URL detected: ${tunnelUrl}`);
                    notifyBackend(tunnelUrl).then(() => resolve(tunnelUrl));
                }
            }
        };
        proc.stdout?.on('data', handleData);
        proc.stderr?.on('data', handleData);
        proc.on('error', (err) => {
            console.error('[Tunnel] Process error:', err.message);
            if (!resolved) {
                resolved = true;
                clearTimeout(timeout);
                tunnelProcess = null;
                tunnelUrl = '';
                reject(err);
            }
        });
        proc.on('exit', (code) => {
            console.log(`[Tunnel] Process exited with code ${code}`);
            tunnelProcess = null;
            const oldUrl = tunnelUrl;
            tunnelUrl = '';
            if (oldUrl) {
                notifyBackend('');
            }
            if (!resolved) {
                resolved = true;
                clearTimeout(timeout);
                reject(new Error(`cloudflared exited with code ${code}`));
            }
        });
    });
}
/**
 * Stop the cloudflared tunnel.
 */
async function stopTunnel() {
    if (tunnelProcess) {
        console.log('[Tunnel] Stopping...');
        tunnelProcess.kill();
        tunnelProcess = null;
    }
    tunnelUrl = '';
    await notifyBackend('');
}
/**
 * Get the current tunnel URL (empty string if not active).
 */
function getTunnelUrl() {
    return tunnelUrl;
}
