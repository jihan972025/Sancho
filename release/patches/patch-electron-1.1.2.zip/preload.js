"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
electron_1.contextBridge.exposeInMainWorld('electronAPI', {
    getAppPath: () => electron_1.ipcRenderer.invoke('get-app-path'),
    isDev: () => electron_1.ipcRenderer.invoke('is-dev'),
    setSelectedModel: (model) => electron_1.ipcRenderer.invoke('set-selected-model', model),
    whatsapp: {
        connect: (waVersion) => electron_1.ipcRenderer.invoke('whatsapp:connect', waVersion),
        disconnect: () => electron_1.ipcRenderer.invoke('whatsapp:disconnect'),
        getStatus: () => electron_1.ipcRenderer.invoke('whatsapp:status'),
        onQR: (cb) => {
            electron_1.ipcRenderer.on('whatsapp:qr', (_event, qr) => cb(qr));
        },
        onStatusUpdate: (cb) => {
            electron_1.ipcRenderer.on('whatsapp:status-update', (_event, s, error) => cb(s, error));
        },
        onChatMessage: (cb) => {
            electron_1.ipcRenderer.on('whatsapp:chat-message', (_event, msg) => cb(msg));
        },
        onTyping: (cb) => {
            electron_1.ipcRenderer.on('whatsapp:chat-typing', (_event, typing) => cb(typing));
        },
        removeSettingsListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('whatsapp:qr');
            electron_1.ipcRenderer.removeAllListeners('whatsapp:status-update');
        },
        removeChatListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('whatsapp:chat-message');
            electron_1.ipcRenderer.removeAllListeners('whatsapp:chat-typing');
        },
    },
    telegram: {
        connect: (apiId, apiHash) => electron_1.ipcRenderer.invoke('telegram:connect', apiId, apiHash),
        disconnect: () => electron_1.ipcRenderer.invoke('telegram:disconnect'),
        getStatus: () => electron_1.ipcRenderer.invoke('telegram:status'),
        onQR: (cb) => {
            electron_1.ipcRenderer.on('telegram:qr', (_event, qr) => cb(qr));
        },
        onStatusUpdate: (cb) => {
            electron_1.ipcRenderer.on('telegram:status-update', (_event, s) => cb(s));
        },
        onChatMessage: (cb) => {
            electron_1.ipcRenderer.on('telegram:chat-message', (_event, msg) => cb(msg));
        },
        onTyping: (cb) => {
            electron_1.ipcRenderer.on('telegram:chat-typing', (_event, typing) => cb(typing));
        },
        removeSettingsListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('telegram:qr');
            electron_1.ipcRenderer.removeAllListeners('telegram:status-update');
        },
        removeChatListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('telegram:chat-message');
            electron_1.ipcRenderer.removeAllListeners('telegram:chat-typing');
        },
    },
    patch: {
        check: () => electron_1.ipcRenderer.invoke('patch:check'),
        apply: () => electron_1.ipcRenderer.invoke('patch:apply'),
        dismiss: (version) => electron_1.ipcRenderer.invoke('patch:dismiss', version),
        restart: () => electron_1.ipcRenderer.invoke('patch:restart'),
        onAvailable: (cb) => {
            electron_1.ipcRenderer.on('patch:available', (_event, info) => cb(info));
        },
        onProgress: (cb) => {
            electron_1.ipcRenderer.on('patch:progress', (_event, info) => cb(info));
        },
        onApplied: (cb) => {
            electron_1.ipcRenderer.on('patch:applied', () => cb());
        },
        removeListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('patch:available');
            electron_1.ipcRenderer.removeAllListeners('patch:progress');
            electron_1.ipcRenderer.removeAllListeners('patch:applied');
        },
    },
    matrix: {
        connect: (homeserverUrl, userId, password, accessToken) => electron_1.ipcRenderer.invoke('matrix:connect', homeserverUrl, userId, password, accessToken),
        disconnect: () => electron_1.ipcRenderer.invoke('matrix:disconnect'),
        getStatus: () => electron_1.ipcRenderer.invoke('matrix:status'),
        onQR: () => { },
        onStatusUpdate: (cb) => {
            electron_1.ipcRenderer.on('matrix:status-update', (_event, s) => cb(s));
        },
        onChatMessage: (cb) => {
            electron_1.ipcRenderer.on('matrix:chat-message', (_event, msg) => cb(msg));
        },
        onTyping: (cb) => {
            electron_1.ipcRenderer.on('matrix:chat-typing', (_event, typing) => cb(typing));
        },
        removeSettingsListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('matrix:status-update');
        },
        removeChatListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('matrix:chat-message');
            electron_1.ipcRenderer.removeAllListeners('matrix:chat-typing');
        },
    },
    slack: {
        connect: (botToken, appToken) => electron_1.ipcRenderer.invoke('slack:connect', botToken, appToken),
        disconnect: () => electron_1.ipcRenderer.invoke('slack:disconnect'),
        getStatus: () => electron_1.ipcRenderer.invoke('slack:status'),
        onQR: () => { },
        onStatusUpdate: (cb) => {
            electron_1.ipcRenderer.on('slack:status-update', (_event, s) => cb(s));
        },
        onChatMessage: (cb) => {
            electron_1.ipcRenderer.on('slack:chat-message', (_event, msg) => cb(msg));
        },
        onTyping: (cb) => {
            electron_1.ipcRenderer.on('slack:chat-typing', (_event, typing) => cb(typing));
        },
        removeSettingsListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('slack:status-update');
        },
        removeChatListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('slack:chat-message');
            electron_1.ipcRenderer.removeAllListeners('slack:chat-typing');
        },
    },
    discord: {
        connect: (botToken) => electron_1.ipcRenderer.invoke('discord:connect', botToken),
        disconnect: () => electron_1.ipcRenderer.invoke('discord:disconnect'),
        getStatus: () => electron_1.ipcRenderer.invoke('discord:status'),
        onQR: () => { },
        onStatusUpdate: (cb) => {
            electron_1.ipcRenderer.on('discord:status-update', (_event, s) => cb(s));
        },
        onChatMessage: (cb) => {
            electron_1.ipcRenderer.on('discord:chat-message', (_event, msg) => cb(msg));
        },
        onTyping: (cb) => {
            electron_1.ipcRenderer.on('discord:chat-typing', (_event, typing) => cb(typing));
        },
        removeSettingsListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('discord:status-update');
        },
        removeChatListeners: () => {
            electron_1.ipcRenderer.removeAllListeners('discord:chat-message');
            electron_1.ipcRenderer.removeAllListeners('discord:chat-typing');
        },
    },
    googleAuth: {
        login: () => electron_1.ipcRenderer.invoke('google-auth:login'),
        getStatus: () => electron_1.ipcRenderer.invoke('google-auth:status'),
        logout: () => electron_1.ipcRenderer.invoke('google-auth:logout'),
    },
    outlookAuth: {
        login: (clientId, clientSecret) => electron_1.ipcRenderer.invoke('outlook-auth:login', clientId, clientSecret),
        getStatus: () => electron_1.ipcRenderer.invoke('outlook-auth:status'),
        logout: () => electron_1.ipcRenderer.invoke('outlook-auth:logout'),
    },
    tunnel: {
        start: () => electron_1.ipcRenderer.invoke('tunnel:start'),
        stop: () => electron_1.ipcRenderer.invoke('tunnel:stop'),
        getStatus: () => electron_1.ipcRenderer.invoke('tunnel:status'),
    },
});
