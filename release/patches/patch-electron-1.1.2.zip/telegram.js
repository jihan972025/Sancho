"use strict";
/**
 * Telegram connection via GramJS.
 * QR code login → message handling → LLM processing → reply.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initTelegram = initTelegram;
exports.connectTelegram = connectTelegram;
exports.disconnectTelegram = disconnectTelegram;
exports.getTelegramStatus = getTelegramStatus;
exports.sendTelegramMessage = sendTelegramMessage;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const selectedModel_1 = require("./selectedModel");
let client = null;
let mainWin = null;
let status = 'disconnected';
let intentionalDisconnect = false;
const BACKEND_URL = 'http://127.0.0.1:8765';
// ── Session persistence ──
function getSessionDir() {
    const home = process.env.USERPROFILE || process.env.HOME || '';
    return path_1.default.join(home, '.sancho', 'telegram-session');
}
function getSessionFile() {
    return path_1.default.join(getSessionDir(), 'session.txt');
}
function loadSession() {
    try {
        return fs_1.default.readFileSync(getSessionFile(), 'utf-8').trim();
    }
    catch {
        return '';
    }
}
function saveSession(session) {
    const dir = getSessionDir();
    if (!fs_1.default.existsSync(dir)) {
        fs_1.default.mkdirSync(dir, { recursive: true });
    }
    fs_1.default.writeFileSync(getSessionFile(), session, 'utf-8');
}
function clearSession() {
    try {
        fs_1.default.unlinkSync(getSessionFile());
        console.log('[Telegram] Session cleared');
    }
    catch { /* ignore */ }
}
// ── Status ──
function setStatus(s) {
    status = s;
    mainWin?.webContents.send('telegram:status-update', s);
}
// ── Public API ──
function initTelegram(win) {
    mainWin = win;
}
async function connectTelegram(apiId, apiHash) {
    if (client)
        return;
    const numericApiId = parseInt(apiId, 10);
    if (!numericApiId || !apiHash) {
        console.error('[Telegram] api_id and api_hash are required');
        return;
    }
    intentionalDisconnect = false;
    setStatus('connecting');
    try {
        const { TelegramClient } = await Promise.resolve().then(() => __importStar(require('telegram')));
        const { StringSession } = await Promise.resolve().then(() => __importStar(require('telegram/sessions')));
        const { NewMessage } = await Promise.resolve().then(() => __importStar(require('telegram/events')));
        const QRCode = await Promise.resolve().then(() => __importStar(require('qrcode')));
        const session = new StringSession(loadSession());
        client = new TelegramClient(session, numericApiId, apiHash, {
            connectionRetries: 5,
            deviceModel: 'Sancho',
            appVersion: '1.0',
        });
        await client.connect();
        if (!(await client.isUserAuthorized())) {
            // QR code login
            console.log('[Telegram] Not authorized, starting QR login...');
            await client.signInUserWithQrCode({ apiId: numericApiId, apiHash }, {
                qrCode: async (qr) => {
                    const token = qr.token.toString('base64url');
                    const url = `tg://login?token=${token}`;
                    const dataUrl = await QRCode.toDataURL(url, { width: 256 });
                    setStatus('qr');
                    mainWin?.webContents.send('telegram:qr', dataUrl);
                    console.log('[Telegram] QR code generated');
                },
                password: async (hint) => {
                    // 2FA not supported yet via UI — user should disable 2FA or use phone login
                    console.error('[Telegram] 2FA password required (hint:', hint, '). Not supported via QR.');
                    throw new Error('2FA password required. Please disable 2FA or enter password.');
                },
                onError: async (err) => {
                    console.error('[Telegram] Login error:', err.message);
                    return true; // retry
                },
            });
        }
        // Save session
        const savedSession = client.session.save();
        saveSession(savedSession);
        setStatus('connected');
        console.log('[Telegram] Connected');
        // Get own user ID for self-chat detection
        const me = await client.getMe();
        const myId = me.id.toString();
        console.log(`[Telegram] Logged in as: ${me.firstName || ''} ${me.lastName || ''} (ID: ${myId})`);
        // Handle incoming messages
        client.addEventHandler(async (event) => {
            if (intentionalDisconnect)
                return;
            const msg = event.message;
            if (!msg || !msg.text)
                return;
            const chatId = msg.chatId?.toString() || '';
            const senderId = msg.senderId?.toString() || '';
            const isSelfChat = chatId === myId;
            const isOutgoing = msg.out;
            // Only process: incoming from others, or any message in Saved Messages (self-chat)
            if (isOutgoing && !isSelfChat)
                return;
            const text = msg.text;
            const sender = `tg_${chatId}`;
            console.log(`[Telegram] Message: "${text.substring(0, 100)}" chat=${chatId} sender=${senderId} self=${isSelfChat}`);
            // Show in Sancho chat UI
            mainWin?.webContents.send('telegram:chat-message', { role: 'user', content: text, source: 'telegram' });
            mainWin?.webContents.send('telegram:chat-typing', true);
            try {
                const resp = await fetch(`${BACKEND_URL}/api/telegram/process`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ sender, text, model: (0, selectedModel_1.getSelectedModel)() }),
                });
                if (resp.ok) {
                    const data = await resp.json();
                    if (data.reply) {
                        mainWin?.webContents.send('telegram:chat-typing', false);
                        mainWin?.webContents.send('telegram:chat-message', { role: 'assistant', content: data.reply, source: 'telegram' });
                        // Send reply back to Telegram
                        try {
                            if (client?.connected) {
                                await client.sendMessage(isSelfChat ? 'me' : msg.chatId, { message: data.reply });
                                console.log(`[Telegram] Reply sent to ${chatId}`);
                            }
                        }
                        catch (sendErr) {
                            console.error('[Telegram] Failed to send reply:', sendErr);
                        }
                    }
                }
                else {
                    console.error('[Telegram] Backend error:', resp.status);
                    mainWin?.webContents.send('telegram:chat-typing', false);
                }
            }
            catch (err) {
                console.error('[Telegram] Failed to process message:', err);
                mainWin?.webContents.send('telegram:chat-typing', false);
            }
        }, new NewMessage({}));
        // Handle disconnection
        client.addEventHandler((update) => {
            if (update.className === 'UpdateLoginToken')
                return;
        });
    }
    catch (err) {
        console.error('[Telegram] Connection error:', err);
        client = null;
        setStatus('disconnected');
    }
}
async function disconnectTelegram() {
    intentionalDisconnect = true;
    if (client) {
        try {
            await client.disconnect();
        }
        catch { /* ignore */ }
        client = null;
    }
    setStatus('disconnected');
}
function getTelegramStatus() {
    return status;
}
async function sendTelegramMessage(text) {
    if (!client?.connected || status !== 'connected')
        return false;
    try {
        await client.sendMessage('me', { message: text });
        console.log('[Telegram] Scheduler notification sent to Saved Messages');
        return true;
    }
    catch (err) {
        console.error('[Telegram] Failed to send scheduler notification:', err);
        return false;
    }
}
