"use strict";
/**
 * Discord connection via discord.js (Bot token).
 * No QR code — token-based auth only (same pattern as Slack).
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.initDiscord = initDiscord;
exports.connectDiscord = connectDiscord;
exports.disconnectDiscord = disconnectDiscord;
exports.getDiscordStatus = getDiscordStatus;
exports.sendDiscordMessage = sendDiscordMessage;
const selectedModel_1 = require("./selectedModel");
let client = null; // Discord.js Client instance
let mainWin = null;
let status = 'disconnected';
let intentionalDisconnect = false;
const BACKEND_URL = 'http://127.0.0.1:8765';
// ── Status ──
function setStatus(s) {
    status = s;
    mainWin?.webContents.send('discord:status-update', s);
}
// ── Public API ──
function initDiscord(win) {
    mainWin = win;
}
async function connectDiscord(botToken) {
    if (client)
        return;
    if (!botToken) {
        console.error('[Discord] Bot Token is required');
        return;
    }
    intentionalDisconnect = false;
    setStatus('connecting');
    try {
        const { Client, GatewayIntentBits } = await Promise.resolve().then(() => __importStar(require('discord.js')));
        client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent,
                GatewayIntentBits.DirectMessages,
            ],
        });
        client.once('ready', () => {
            console.log(`[Discord] Logged in as ${client.user?.tag}`);
            setStatus('connected');
        });
        client.on('messageCreate', async (message) => {
            if (intentionalDisconnect)
                return;
            // Skip bot's own messages and other bots
            if (message.author.bot)
                return;
            const text = message.content || '';
            if (!text)
                return;
            // Only respond to DMs or mentions in guild channels
            const isDM = !message.guild;
            const isMentioned = message.mentions?.has(client.user);
            if (!isDM && !isMentioned)
                return;
            // Strip bot mention from text
            const cleanText = isDM ? text : text.replace(/<@!?\d+>/g, '').trim();
            if (!cleanText)
                return;
            const sender = `discord_${message.author.id}_${message.channel.id}`;
            console.log(`[Discord] Message: "${cleanText.substring(0, 100)}" from ${message.author.tag} in ${message.channel.id}`);
            // Show in Sancho chat UI
            mainWin?.webContents.send('discord:chat-message', {
                role: 'user', content: cleanText, source: 'discord',
            });
            mainWin?.webContents.send('discord:chat-typing', true);
            try {
                const resp = await fetch(`${BACKEND_URL}/api/discord/process`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ sender, text: cleanText, model: (0, selectedModel_1.getSelectedModel)() }),
                });
                if (resp.ok) {
                    const data = await resp.json();
                    if (data.reply) {
                        mainWin?.webContents.send('discord:chat-typing', false);
                        mainWin?.webContents.send('discord:chat-message', {
                            role: 'assistant', content: data.reply, source: 'discord',
                        });
                        // Send reply back to Discord
                        try {
                            // Discord has a 2000 char limit per message
                            const reply = data.reply;
                            if (reply.length <= 2000) {
                                await message.reply(reply);
                            }
                            else {
                                // Split into chunks
                                for (let i = 0; i < reply.length; i += 2000) {
                                    const chunk = reply.substring(i, i + 2000);
                                    if (i === 0) {
                                        await message.reply(chunk);
                                    }
                                    else {
                                        await message.channel.send(chunk);
                                    }
                                }
                            }
                            console.log(`[Discord] Reply sent to ${message.channel.id}`);
                        }
                        catch (sendErr) {
                            console.error('[Discord] Failed to send reply:', sendErr);
                        }
                    }
                }
                else {
                    console.error('[Discord] Backend error:', resp.status);
                    mainWin?.webContents.send('discord:chat-typing', false);
                }
            }
            catch (err) {
                console.error('[Discord] Failed to process message:', err);
                mainWin?.webContents.send('discord:chat-typing', false);
            }
        });
        await client.login(botToken);
    }
    catch (err) {
        console.error('[Discord] Connection error:', err);
        client = null;
        setStatus('disconnected');
    }
}
async function disconnectDiscord() {
    intentionalDisconnect = true;
    if (client) {
        try {
            await client.destroy();
        }
        catch { /* ignore */ }
        client = null;
    }
    setStatus('disconnected');
}
function getDiscordStatus() {
    return status;
}
/**
 * Send a scheduler notification to the bot owner's DM.
 */
async function sendDiscordMessage(text) {
    if (!client || status !== 'connected')
        return false;
    try {
        // Get the bot's application owner for DM notifications
        const application = await client.application?.fetch();
        const ownerId = application?.owner?.id;
        if (!ownerId) {
            console.warn('[Discord] Could not find bot owner for DM notification');
            return false;
        }
        const owner = await client.users.fetch(ownerId);
        const dm = await owner.createDM();
        // Discord has a 2000 char limit
        if (text.length <= 2000) {
            await dm.send(text);
        }
        else {
            for (let i = 0; i < text.length; i += 2000) {
                await dm.send(text.substring(i, i + 2000));
            }
        }
        console.log(`[Discord] Scheduler notification sent to owner DM`);
        return true;
    }
    catch (err) {
        console.error('[Discord] Failed to send scheduler notification:', err);
        return false;
    }
}
