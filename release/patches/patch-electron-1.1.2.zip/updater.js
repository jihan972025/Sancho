"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkForUpdate = checkForUpdate;
exports.applyPatch = applyPatch;
exports.startPeriodicCheck = startPeriodicCheck;
exports.stopPeriodicCheck = stopPeriodicCheck;
exports.dismissUpdate = dismissUpdate;
const electron_1 = require("electron");
const child_process_1 = require("child_process");
const crypto_1 = __importDefault(require("crypto"));
const https_1 = __importDefault(require("https"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const GITHUB_API_URL = 'https://api.github.com/repos/jihan972025/sancho/releases/latest';
const CHECK_INTERVAL = 60 * 60 * 1000; // 60 minutes
const INITIAL_DELAY = 10 * 1000; // 10 seconds
const CHANNEL_NAMES = ['frontend', 'electron', 'backend', 'html'];
let periodicTimer = null;
let initialTimer = null;
let dismissedVersion = null;
let win = null;
// ── Network helpers ────────────────────────────────────────────
function httpsGet(url) {
    return new Promise((resolve, reject) => {
        const options = { headers: { 'User-Agent': 'Sancho-Updater' } };
        https_1.default.get(url, options, (res) => {
            if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                httpsGet(res.headers.location).then(resolve).catch(reject);
                return;
            }
            if (res.statusCode !== 200) {
                reject(new Error(`HTTP ${res.statusCode}`));
                return;
            }
            let data = '';
            res.on('data', (chunk) => { data += chunk.toString(); });
            res.on('end', () => resolve(data));
            res.on('error', reject);
        }).on('error', reject);
    });
}
function httpsDownload(url, destPath, onProgress) {
    return new Promise((resolve, reject) => {
        const options = { headers: { 'User-Agent': 'Sancho-Updater' } };
        https_1.default.get(url, options, (res) => {
            if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                httpsDownload(res.headers.location, destPath, onProgress).then(resolve).catch(reject);
                return;
            }
            if (res.statusCode !== 200) {
                reject(new Error(`HTTP ${res.statusCode}`));
                return;
            }
            const totalSize = parseInt(res.headers['content-length'] || '0', 10);
            let downloaded = 0;
            const file = fs_1.default.createWriteStream(destPath);
            res.on('data', (chunk) => {
                downloaded += chunk.length;
                onProgress?.(downloaded, totalSize);
            });
            res.pipe(file);
            file.on('finish', () => { file.close(); resolve(); });
            file.on('error', (err) => { fs_1.default.unlinkSync(destPath); reject(err); });
        }).on('error', reject);
    });
}
// ── Version helpers ────────────────────────────────────────────
function compareVersions(current, remote) {
    // Returns true if remote is newer than current
    const cleanVer = (v) => v.replace(/^v/, '');
    const cParts = cleanVer(current).split('.').map(Number);
    const rParts = cleanVer(remote).split('.').map(Number);
    for (let i = 0; i < Math.max(cParts.length, rParts.length); i++) {
        const c = cParts[i] || 0;
        const r = rParts[i] || 0;
        if (r > c)
            return true;
        if (r < c)
            return false;
    }
    return false;
}
function fileSha256(filePath) {
    return new Promise((resolve, reject) => {
        const hash = crypto_1.default.createHash('sha256');
        const stream = fs_1.default.createReadStream(filePath);
        stream.on('data', (chunk) => hash.update(chunk));
        stream.on('end', () => resolve(hash.digest('hex')));
        stream.on('error', reject);
    });
}
function formatSize(bytes) {
    if (bytes < 1024)
        return `${bytes} B`;
    if (bytes < 1024 * 1024)
        return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
// ── Local version tracking ─────────────────────────────────────
function getLocalPatchVersion() {
    try {
        const versionPath = path_1.default.join(process.resourcesPath, 'patch-version.json');
        return JSON.parse(fs_1.default.readFileSync(versionPath, 'utf-8'));
    }
    catch {
        const v = electron_1.app.getVersion();
        return { version: v, channels: { frontend: v, electron: v, backend: v, html: v } };
    }
}
function saveLocalPatchVersion(pv) {
    try {
        const versionPath = path_1.default.join(process.resourcesPath, 'patch-version.json');
        fs_1.default.writeFileSync(versionPath, JSON.stringify(pv, null, 2));
    }
    catch (err) {
        console.error('[Updater] Failed to save patch-version.json:', err.message);
    }
}
// ── Release helpers ────────────────────────────────────────────
function getAssetUrl(release, assetName) {
    const asset = release.assets.find((a) => a.name === assetName);
    return asset ? asset.browser_download_url : null;
}
async function fetchManifest(release) {
    const url = getAssetUrl(release, 'patch-manifest.json');
    if (!url)
        return null;
    try {
        const data = await httpsGet(url);
        return JSON.parse(data);
    }
    catch {
        return null;
    }
}
// ── Effective version (patch-version.json > app.getVersion()) ──
function getEffectiveVersion() {
    const pv = getLocalPatchVersion();
    // If patch-version.json has a newer version than the built-in app version, use it
    if (compareVersions(electron_1.app.getVersion(), pv.version))
        return pv.version;
    return pv.version || electron_1.app.getVersion();
}
// ── Check for update ───────────────────────────────────────────
async function checkForUpdate() {
    try {
        const data = await httpsGet(GITHUB_API_URL);
        const release = JSON.parse(data);
        const currentVersion = getEffectiveVersion();
        const remoteVersion = release.tag_name.replace(/^v/, '');
        console.log(`[Updater] Current: ${currentVersion}, Remote: ${remoteVersion}`);
        if (!compareVersions(currentVersion, remoteVersion)) {
            console.log(`[Updater] No update: current ${currentVersion} >= remote ${remoteVersion}`);
            return { available: false };
        }
        // Try to get patch manifest for size/channel info
        const manifest = await fetchManifest(release);
        if (!manifest || manifest.requires_full_update) {
            const installerAsset = release.assets.find((a) => a.name.endsWith('.exe') && a.name.includes('Setup'));
            return {
                available: true,
                version: remoteVersion,
                notes: release.body || release.name,
                patchSize: installerAsset?.size || 0,
                channels: [],
                fullOnly: true,
            };
        }
        // Check min_version: if installed version is too old → full only
        if (compareVersions(currentVersion, manifest.min_version)) {
            const installerAsset = release.assets.find((a) => a.name.endsWith('.exe') && a.name.includes('Setup'));
            return {
                available: true,
                version: remoteVersion,
                notes: release.body || release.name,
                patchSize: installerAsset?.size || 0,
                channels: [],
                fullOnly: true,
            };
        }
        // Determine which channels changed
        const local = getLocalPatchVersion();
        const changedChannels = [];
        let totalPatchSize = 0;
        for (const ch of CHANNEL_NAMES) {
            const channelInfo = manifest.channels[ch];
            if (!channelInfo)
                continue;
            const localVer = local.channels[ch] || local.version;
            if (localVer !== manifest.version) {
                changedChannels.push(ch);
                totalPatchSize += channelInfo.size;
            }
        }
        return {
            available: true,
            version: remoteVersion,
            notes: release.body || release.name,
            patchSize: totalPatchSize,
            channels: changedChannels,
            fullOnly: false,
        };
    }
    catch (err) {
        console.log('[Updater] Check failed:', err.message);
        return { available: false };
    }
}
// ── Full installer update (existing approach) ──────────────────
async function applyFullUpdate(onProgress, targetVersion) {
    const data = await httpsGet(GITHUB_API_URL);
    const release = JSON.parse(data);
    const remoteVersion = targetVersion || release.tag_name.replace(/^v/, '');
    const installerAsset = release.assets.find((a) => a.name.endsWith('.exe') && a.name.includes('Setup'));
    if (!installerAsset) {
        return { success: false, error: 'No installer found in release.' };
    }
    const tempDir = electron_1.app.getPath('temp');
    const installerPath = path_1.default.join(tempDir, installerAsset.name);
    console.log(`[Updater] Downloading installer: ${installerAsset.name} (${formatSize(installerAsset.size)})`);
    await httpsDownload(installerAsset.browser_download_url, installerPath, (downloaded, total) => {
        if (total > 0)
            onProgress?.(Math.round((downloaded / total) * 100));
    });
    const appExePath = process.execPath;
    const installDir = path_1.default.dirname(appExePath);
    const batchPath = path_1.default.join(tempDir, 'sancho-update.bat');
    const logPath = path_1.default.join(tempDir, 'sancho-update.log');
    // Write updated patch-version.json to temp for batch to copy after install
    const newPatchVersion = {
        version: remoteVersion,
        channels: { frontend: remoteVersion, electron: remoteVersion, backend: remoteVersion, html: remoteVersion },
    };
    const versionTmpPath = path_1.default.join(tempDir, 'patch-version-full.json');
    fs_1.default.writeFileSync(versionTmpPath, JSON.stringify(newPatchVersion, null, 2));
    const versionTargetPath = path_1.default.join(installDir, 'resources', 'patch-version.json').replace(/\//g, '\\');
    const batchContent = [
        '@echo off',
        'chcp 65001 >nul',
        `echo [%date% %time%] Full update started >> "${logPath}"`,
        'taskkill /F /IM "Sancho.exe" 2>nul',
        'taskkill /F /IM "main.exe" 2>nul',
        'taskkill /F /IM "cloudflared.exe" 2>nul',
        `echo [%date% %time%] Processes killed >> "${logPath}"`,
        'ping -n 6 127.0.0.1 > nul 2>&1',
        `echo [%date% %time%] Running installer... >> "${logPath}"`,
        `"${installerPath}" /S`,
        `echo [%date% %time%] Installer exited (%ERRORLEVEL%) >> "${logPath}"`,
        'ping -n 4 127.0.0.1 > nul 2>&1',
        // After install, overwrite patch-version.json with correct version
        `echo [%date% %time%] Updating patch-version.json to ${remoteVersion}... >> "${logPath}"`,
        `copy /Y "${versionTmpPath.replace(/\//g, '\\')}" "${versionTargetPath}" >nul 2>&1`,
        `if %ERRORLEVEL% NEQ 0 (echo [%date% %time%] WARNING: patch-version copy failed >> "${logPath}")`,
        `del "${versionTmpPath.replace(/\//g, '\\')}" 2>nul`,
        `start "" "${appExePath}"`,
        `del "${installerPath}" 2>nul`,
        `echo [%date% %time%] Complete >> "${logPath}"`,
        'del "%~f0" 2>nul',
    ].join('\r\n');
    fs_1.default.writeFileSync(batchPath, batchContent);
    // Use cmd.exe directly instead of VBS to avoid encoding issues with non-ASCII paths
    const child = (0, child_process_1.spawn)('cmd.exe', ['/c', 'start', '/min', '""', batchPath], {
        detached: true, stdio: 'ignore', windowsHide: true,
    });
    child.unref();
    setTimeout(() => electron_1.app.exit(0), 500);
    return { success: true };
}
// ── Differential patch update ──────────────────────────────────
async function applyDifferentialPatch(onProgress) {
    const data = await httpsGet(GITHUB_API_URL);
    const release = JSON.parse(data);
    const manifest = await fetchManifest(release);
    if (!manifest)
        return { success: false, error: 'Patch manifest not found.' };
    // Determine channels to update
    const local = getLocalPatchVersion();
    const channelsToUpdate = [];
    for (const ch of CHANNEL_NAMES) {
        const info = manifest.channels[ch];
        if (!info)
            continue;
        if ((local.channels[ch] || local.version) !== manifest.version) {
            channelsToUpdate.push(ch);
        }
    }
    if (channelsToUpdate.length === 0) {
        // No channels changed but version is newer — update local version tracking
        local.version = manifest.version;
        for (const ch of CHANNEL_NAMES) {
            local.channels[ch] = manifest.version;
        }
        saveLocalPatchVersion(local);
        console.log(`[Updater] No channel patches needed, version bumped to ${manifest.version}`);
        return { success: true };
    }
    // Total download size for progress tracking
    const totalSize = channelsToUpdate.reduce((sum, ch) => sum + manifest.channels[ch].size, 0);
    let downloadedOverall = 0;
    // Create staging directory
    const stagingDir = path_1.default.join(electron_1.app.getPath('temp'), 'sancho-patch');
    fs_1.default.mkdirSync(stagingDir, { recursive: true });
    // Download all needed patches
    for (const ch of channelsToUpdate) {
        const info = manifest.channels[ch];
        const assetUrl = getAssetUrl(release, info.asset);
        if (!assetUrl) {
            fs_1.default.rmSync(stagingDir, { recursive: true, force: true });
            return { success: false, error: `Patch asset not found: ${info.asset}` };
        }
        const destPath = path_1.default.join(stagingDir, info.asset);
        console.log(`[Updater] Downloading ${ch} patch: ${info.asset} (${formatSize(info.size)})`);
        const channelStart = downloadedOverall;
        await httpsDownload(assetUrl, destPath, (downloaded) => {
            if (totalSize > 0) {
                onProgress?.(Math.min(Math.round(((channelStart + downloaded) / totalSize) * 100), 99), ch);
            }
        });
        downloadedOverall += info.size;
        // Verify SHA-256
        const actualHash = await fileSha256(destPath);
        if (actualHash !== info.sha256) {
            console.error(`[Updater] SHA-256 mismatch for ${ch}`);
            fs_1.default.rmSync(stagingDir, { recursive: true, force: true });
            return { success: false, error: `Checksum mismatch for ${ch} patch.` };
        }
        console.log(`[Updater] ${ch} verified OK`);
    }
    onProgress?.(100);
    // Decide: hot-reload or restart
    const needsRestart = channelsToUpdate.some((ch) => ch === 'electron' || ch === 'backend');
    if (needsRestart) {
        return applyWithRestart(stagingDir, channelsToUpdate, manifest);
    }
    else {
        return applyHotReload(stagingDir, channelsToUpdate, manifest);
    }
}
// ── Hot-reload (frontend/html only — no restart) ───────────────
function applyHotReload(stagingDir, channels, manifest) {
    try {
        for (const ch of channels) {
            const info = manifest.channels[ch];
            const zipPath = path_1.default.join(stagingDir, info.asset);
            const targetDir = path_1.default.join(process.resourcesPath, info.target);
            console.log(`[Updater] Hot-apply ${ch} → ${targetDir}`);
            fs_1.default.mkdirSync(targetDir, { recursive: true });
            (0, child_process_1.execSync)(`powershell -NoProfile -Command "Expand-Archive -Force '${zipPath}' '${targetDir}'"`, { timeout: 60000 });
        }
        // Update local version
        const local = getLocalPatchVersion();
        for (const ch of channels)
            local.channels[ch] = manifest.version;
        local.version = manifest.version;
        saveLocalPatchVersion(local);
        // Cleanup staging
        fs_1.default.rmSync(stagingDir, { recursive: true, force: true });
        // Reload renderer
        if (win && !win.isDestroyed())
            win.webContents.reload();
        console.log('[Updater] Hot-reload complete');
        return { success: true };
    }
    catch (err) {
        return { success: false, error: err.message };
    }
}
// ── Restart-required apply (backend/electron changes) ──────────
function applyWithRestart(stagingDir, channels, manifest) {
    const tempDir = electron_1.app.getPath('temp');
    const appExePath = process.execPath;
    const installDir = path_1.default.dirname(appExePath);
    const batchPath = path_1.default.join(tempDir, 'sancho-patch.bat');
    const logPath = path_1.default.join(tempDir, 'sancho-patch.log');
    // Build extraction commands per channel
    const extractCmds = [];
    for (const ch of channels) {
        const info = manifest.channels[ch];
        const zipPath = path_1.default.join(stagingDir, info.asset).replace(/\//g, '\\');
        const targetDir = path_1.default.join(installDir, 'resources', info.target).replace(/\//g, '\\');
        extractCmds.push(`echo [%date% %time%] Extracting ${ch}... >> "${logPath}"`, `powershell -NoProfile -Command "Expand-Archive -Force '${zipPath}' '${targetDir}'"`, `if %ERRORLEVEL% NEQ 0 (echo [%date% %time%] FAILED: ${ch} >> "${logPath}" & goto :error)`);
    }
    // Build updated patch-version.json
    const local = getLocalPatchVersion();
    for (const ch of channels)
        local.channels[ch] = manifest.version;
    local.version = manifest.version;
    const versionJsonPath = path_1.default.join(installDir, 'resources', 'patch-version.json').replace(/\//g, '\\');
    // Write as a temp file then copy (avoid echo quoting issues)
    const versionTmpPath = path_1.default.join(tempDir, 'patch-version-new.json').replace(/\//g, '\\');
    fs_1.default.writeFileSync(versionTmpPath.replace(/\\\\/g, '\\'), JSON.stringify(local, null, 2));
    const batchContent = [
        '@echo off',
        'chcp 65001 >nul',
        `echo [%date% %time%] Differential patch started >> "${logPath}"`,
        'taskkill /F /IM "Sancho.exe" 2>nul',
        'taskkill /F /IM "main.exe" 2>nul',
        'taskkill /F /IM "cloudflared.exe" 2>nul',
        `echo [%date% %time%] Processes killed >> "${logPath}"`,
        'ping -n 4 127.0.0.1 > nul 2>&1',
        '',
        ...extractCmds,
        '',
        `echo [%date% %time%] Updating version... >> "${logPath}"`,
        `copy /Y "${versionTmpPath}" "${versionJsonPath}" >nul`,
        '',
        `echo [%date% %time%] Cleaning staging... >> "${logPath}"`,
        `rmdir /S /Q "${stagingDir.replace(/\//g, '\\')}" 2>nul`,
        `del "${versionTmpPath}" 2>nul`,
        '',
        'ping -n 3 127.0.0.1 > nul 2>&1',
        `echo [%date% %time%] Launching app... >> "${logPath}"`,
        `start "" "${appExePath}"`,
        `echo [%date% %time%] Patch complete >> "${logPath}"`,
        'goto :end',
        '',
        ':error',
        `echo [%date% %time%] Patch FAILED >> "${logPath}"`,
        `start "" "${appExePath}"`,
        '',
        ':end',
        'del "%~f0" 2>nul',
    ].join('\r\n');
    fs_1.default.writeFileSync(batchPath, batchContent);
    console.log(`[Updater] Launching patch script: ${batchPath}`);
    // Verify batch file exists before spawning
    if (!fs_1.default.existsSync(batchPath)) {
        return { success: false, error: `Batch file not created: ${batchPath}` };
    }
    // Use cmd.exe directly instead of VBS to avoid encoding issues with non-ASCII paths
    const child = (0, child_process_1.spawn)('cmd.exe', ['/c', 'start', '/min', '""', batchPath], {
        detached: true, stdio: 'ignore', windowsHide: true,
    });
    child.unref();
    setTimeout(() => electron_1.app.exit(0), 1000);
    return { success: true };
}
// ── Main entry: applyPatch ─────────────────────────────────────
async function applyPatch(onProgress) {
    try {
        const data = await httpsGet(GITHUB_API_URL);
        const release = JSON.parse(data);
        const manifest = await fetchManifest(release);
        const remoteVersion = release.tag_name.replace(/^v/, '');
        // No manifest or full update required → full installer
        if (!manifest || manifest.requires_full_update) {
            console.log('[Updater] Using full installer update');
            return applyFullUpdate((percent) => onProgress?.(percent), remoteVersion);
        }
        // Current version too old → full installer
        const currentVersion = getEffectiveVersion();
        if (compareVersions(currentVersion, manifest.min_version)) {
            console.log(`[Updater] ${currentVersion} < min ${manifest.min_version}, full installer`);
            return applyFullUpdate((percent) => onProgress?.(percent), remoteVersion);
        }
        // Differential patch
        console.log('[Updater] Using differential patch');
        return applyDifferentialPatch(onProgress);
    }
    catch (err) {
        console.log('[Updater] Diff patch failed, fallback to full:', err.message);
        return applyFullUpdate((percent) => onProgress?.(percent));
    }
}
// ── Periodic check ─────────────────────────────────────────────
async function doCheck() {
    if (!win || win.isDestroyed())
        return;
    const result = await checkForUpdate();
    if (result.available && result.version !== dismissedVersion) {
        win.webContents.send('patch:available', {
            version: result.version,
            notes: result.notes,
            patchSize: result.patchSize,
            channels: result.channels,
            fullOnly: result.fullOnly,
        });
    }
}
function startPeriodicCheck(mainWindow) {
    win = mainWindow;
    initialTimer = setTimeout(() => {
        doCheck();
        periodicTimer = setInterval(doCheck, CHECK_INTERVAL);
    }, INITIAL_DELAY);
}
function stopPeriodicCheck() {
    if (initialTimer) {
        clearTimeout(initialTimer);
        initialTimer = null;
    }
    if (periodicTimer) {
        clearInterval(periodicTimer);
        periodicTimer = null;
    }
    win = null;
}
function dismissUpdate(version) {
    dismissedVersion = version;
}
