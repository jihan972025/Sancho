"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setSelectedModel = setSelectedModel;
exports.getSelectedModel = getSelectedModel;
/** Shared selected model state across Electron main process modules. */
let _selectedModel = '';
function setSelectedModel(model) {
    _selectedModel = model;
}
function getSelectedModel() {
    return _selectedModel;
}
