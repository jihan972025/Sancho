"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const child_process_1 = require("child_process");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const whatsapp_1 = require("./whatsapp");
const telegram_1 = require("./telegram");
const matrix_1 = require("./matrix");
const slack_1 = require("./slack");
// Discord: lazy-loaded to support differential patching (new file not in original asar)
let _discord = null;
function getDiscordModule() {
    if (!_discord) {
        try {
            // Try asar.unpacked path first (for patched installs), then normal require
            const unpackedPath = __dirname.replace('app.asar', 'app.asar.unpacked');
            const discordPath = require('path').join(unpackedPath, 'discord');
            if (require('fs').existsSync(discordPath + '.js')) {
                _discord = require(discordPath);
            }
            else {
                _discord = require('./discord');
            }
        }
        catch {
            _discord = null;
        }
    }
    return _discord;
}
const initDiscord = (...args) => getDiscordModule()?.initDiscord(...args);
const connectDiscord = (...args) => getDiscordModule()?.connectDiscord(...args) ?? Promise.resolve();
const disconnectDiscord = (...args) => getDiscordModule()?.disconnectDiscord(...args);
const getDiscordStatus = () => getDiscordModule()?.getDiscordStatus() ?? 'disconnected';
const sendDiscordMessage = (...args) => getDiscordModule()?.sendDiscordMessage(...args) ?? Promise.resolve(false);
const selectedModel_1 = require("./selectedModel");
const updater_1 = require("./updater");
const googleAuth_1 = require("./googleAuth");
const outlookAuth_1 = require("./outlookAuth");
const tunnel_1 = require("./tunnel");
let mainWindow = null;
let pythonProcess = null;
let notificationPollTimer = null;
let tradePollTimer = null;
let tray = null;
let isQuitting = false;
const isDev = !electron_1.app.isPackaged;
/** Return patched version from patch-version.json, falling back to app.getVersion(). */
function getDisplayVersion() {
    try {
        const pvPath = path_1.default.join(process.resourcesPath, 'patch-version.json');
        const pv = JSON.parse(fs_1.default.readFileSync(pvPath, 'utf-8'));
        if (pv.version)
            return pv.version;
    }
    catch { /* ignore */ }
    return electron_1.app.getVersion();
}
function findPythonBackend() {
    if (isDev) {
        // Development: run python directly
        return {
            command: 'python',
            args: ['-m', 'uvicorn', 'backend.main:app', '--host', '127.0.0.1', '--port', '8765'],
        };
    }
    // Production: use PyInstaller-built executable
    const backendPath = path_1.default.join(process.resourcesPath, 'backend', 'main.exe');
    if (fs_1.default.existsSync(backendPath)) {
        return { command: backendPath, args: [] };
    }
    // Fallback: try python
    return {
        command: 'python',
        args: ['-m', 'uvicorn', 'backend.main:app', '--host', '127.0.0.1', '--port', '8765'],
    };
}
async function isBackendRunning() {
    try {
        const http = await Promise.resolve().then(() => __importStar(require('http')));
        return new Promise((resolve) => {
            const req = http.get('http://127.0.0.1:8765/api/health', (res) => {
                resolve(res.statusCode === 200);
            });
            req.on('error', () => resolve(false));
            req.setTimeout(1000, () => { req.destroy(); resolve(false); });
        });
    }
    catch {
        return false;
    }
}
async function startBackend() {
    // Skip if backend is already running (e.g. started by start_electron.bat)
    if (await isBackendRunning()) {
        console.log('Backend already running on port 8765, skipping spawn');
        return;
    }
    const { command, args } = findPythonBackend();
    console.log(`Starting backend: ${command} ${args.join(' ')}`);
    const playwrightCliJs = isDev
        ? path_1.default.join(__dirname, '..', 'node_modules', '@playwright', 'cli', 'playwright-cli.js')
        : path_1.default.join(process.resourcesPath, 'app.asar.unpacked', 'node_modules', '@playwright', 'cli', 'playwright-cli.js');
    // In production, use Electron's bundled node; in dev, use system node
    const nodePath = isDev ? 'node' : process.execPath;
    pythonProcess = (0, child_process_1.spawn)(command, args, {
        cwd: isDev ? path_1.default.join(__dirname, '..') : process.resourcesPath,
        stdio: ['pipe', 'pipe', 'pipe'],
        env: {
            ...process.env,
            SANCHO_PLAYWRIGHT_CLI_JS: playwrightCliJs,
            SANCHO_PLAYWRIGHT_NODE: nodePath,
        },
    });
    pythonProcess.stdout?.on('data', (data) => {
        console.log(`[Backend] ${data.toString().trim()}`);
    });
    pythonProcess.stderr?.on('data', (data) => {
        console.error(`[Backend] ${data.toString().trim()}`);
    });
    pythonProcess.on('error', (err) => {
        console.error('Failed to start backend:', err.message);
    });
    pythonProcess.on('exit', (code) => {
        console.log(`Backend exited with code ${code}`);
        pythonProcess = null;
    });
}
function stopBackend() {
    if (pythonProcess) {
        pythonProcess.kill();
        pythonProcess = null;
    }
}
function createWindow() {
    const titlebarIcon = isDev
        ? path_1.default.join(__dirname, '..', 'img', 'android-chrome-192x192.webp')
        : path_1.default.join(process.resourcesPath, 'assets', 'app-icon.webp');
    mainWindow = new electron_1.BrowserWindow({
        width: 1200,
        height: 800,
        minWidth: 800,
        minHeight: 600,
        title: `Sancho v${getDisplayVersion()}`,
        icon: titlebarIcon,
        frame: true,
        backgroundColor: '#0f172a',
        show: false,
        webPreferences: {
            preload: isDev
                ? path_1.default.join(__dirname, 'preload.js')
                : path_1.default.join(process.resourcesPath, 'app.asar.unpacked', 'dist-electron', 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            webSecurity: false, // Required: file:// → http://127.0.0.1:8765 API calls
        },
    });
    mainWindow.once('ready-to-show', () => {
        mainWindow?.show();
    });
    if (isDev) {
        // Load splash screen first — it polls backend + Vite and redirects when ready
        const loadingPath = path_1.default.join(__dirname, '..', 'electron', 'loading.html');
        if (fs_1.default.existsSync(loadingPath)) {
            mainWindow.loadFile(loadingPath);
        }
        else {
            mainWindow.loadURL('http://localhost:5173');
        }
    }
    else {
        mainWindow.loadFile(path_1.default.join(process.resourcesPath, 'app.asar.unpacked', 'dist', 'index.html'));
    }
    mainWindow.on('close', (e) => {
        if (!isQuitting) {
            e.preventDefault();
            mainWindow?.hide();
        }
    });
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}
async function fetchSettings() {
    const http = await Promise.resolve().then(() => __importStar(require('http')));
    const data = await new Promise((resolve, reject) => {
        http.get('http://127.0.0.1:8765/api/settings', (res) => {
            let body = '';
            res.on('data', (chunk) => { body += chunk.toString(); });
            res.on('end', () => resolve(body));
            res.on('error', reject);
        }).on('error', reject);
    });
    return JSON.parse(data);
}
async function autoConnectChatApps() {
    try {
        const config = await fetchSettings();
        // WhatsApp auto-connect
        if (config.whatsapp?.enabled) {
            const waVersion = config.whatsapp.wa_version || undefined;
            console.log('[WhatsApp] Auto-connecting (enabled in settings)...');
            (0, whatsapp_1.connectWhatsApp)(waVersion).catch((err) => console.log('[WhatsApp] Auto-connect failed:', err.message));
        }
        // Telegram auto-connect
        if (config.telegram?.enabled && config.telegram?.api_id && config.telegram?.api_hash) {
            console.log('[Telegram] Auto-connecting (enabled in settings)...');
            (0, telegram_1.connectTelegram)(config.telegram.api_id, config.telegram.api_hash).catch((err) => console.log('[Telegram] Auto-connect failed:', err.message));
        }
        // Matrix auto-connect
        if (config.matrix?.enabled && config.matrix?.user_id) {
            console.log('[Matrix] Auto-connecting (enabled in settings)...');
            (0, matrix_1.connectMatrix)(config.matrix.homeserver_url, config.matrix.user_id, config.matrix.password, config.matrix.access_token).catch((err) => console.log('[Matrix] Auto-connect failed:', err.message));
        }
        // Slack auto-connect
        if (config.slack?.enabled && config.api?.slack_bot_token && config.api?.slack_app_token) {
            console.log('[Slack] Auto-connecting (enabled in settings)...');
            (0, slack_1.connectSlack)(config.api.slack_bot_token, config.api.slack_app_token).catch((err) => console.log('[Slack] Auto-connect failed:', err.message));
        }
        // Discord auto-connect
        if (config.discord?.enabled && config.discord?.bot_token) {
            console.log('[Discord] Auto-connecting (enabled in settings)...');
            connectDiscord(config.discord.bot_token).catch((err) => console.log('[Discord] Auto-connect failed:', err.message));
        }
    }
    catch (err) {
        console.log('[ChatApps] Auto-connect skipped:', err.message);
    }
}
const BACKEND_URL = 'http://127.0.0.1:8765';
const POLL_INTERVAL = 30000; // 30 seconds
async function pollSchedulerNotifications() {
    try {
        const resp = await fetch(`${BACKEND_URL}/api/scheduler/notifications`);
        if (!resp.ok)
            return;
        const { notifications } = await resp.json();
        if (!notifications || notifications.length === 0)
            return;
        const ackedIds = [];
        for (const notif of notifications) {
            const header = `[${notif.task_name}]\n`;
            // Trim long results for chat messages (max 3000 chars)
            const body = notif.result.length > 3000
                ? notif.result.substring(0, 3000) + '\n...(truncated)'
                : notif.result;
            const message = header + body;
            const apps = notif.notify_apps || {};
            let sent = false;
            if (apps.whatsapp && (0, whatsapp_1.getWhatsAppStatus)() === 'connected') {
                if (await (0, whatsapp_1.sendWhatsAppMessage)(message))
                    sent = true;
            }
            if (apps.telegram && (0, telegram_1.getTelegramStatus)() === 'connected') {
                if (await (0, telegram_1.sendTelegramMessage)(message))
                    sent = true;
            }
            if (apps.matrix && (0, matrix_1.getMatrixStatus)() === 'connected') {
                if (await (0, matrix_1.sendMatrixMessage)(message))
                    sent = true;
            }
            if (apps.slack && (0, slack_1.getSlackStatus)() === 'connected') {
                if (await (0, slack_1.sendSlackMessage)(message))
                    sent = true;
            }
            if (apps.discord && getDiscordStatus() === 'connected') {
                if (await sendDiscordMessage(message))
                    sent = true;
            }
            if (sent) {
                ackedIds.push(notif.id);
                // Also notify UI
                mainWindow?.webContents.send('scheduler:notification-sent', {
                    task_name: notif.task_name,
                    apps,
                });
            }
        }
        // Ack delivered notifications
        if (ackedIds.length > 0) {
            await fetch(`${BACKEND_URL}/api/scheduler/notifications/ack`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ids: ackedIds }),
            });
            console.log(`[Scheduler] Acked ${ackedIds.length} notification(s)`);
        }
    }
    catch (err) {
        // Silent fail — backend may not be ready yet
    }
}
function startNotificationPolling() {
    if (notificationPollTimer)
        return;
    notificationPollTimer = setInterval(pollSchedulerNotifications, POLL_INTERVAL);
    // Also run immediately once
    pollSchedulerNotifications();
    console.log('[Scheduler] Notification polling started (30s interval)');
}
function stopNotificationPolling() {
    if (notificationPollTimer) {
        clearInterval(notificationPollTimer);
        notificationPollTimer = null;
    }
}
// ── Auto-Trading Trade Notifications ──
const TRADE_POLL_INTERVAL = 10000; // 10 seconds
function formatTradeNotification(notif) {
    const data = notif.trade_data || {};
    const prefix = notif.source === 'manual' ? '[Manual Trade]' : '[Auto-Trading]';
    const time = new Date(notif.created_at).toLocaleString();
    if (notif.action === 'BUY') {
        const price = Number(data.price || 0).toLocaleString();
        const amount = Number(data.amount_krw || 0).toLocaleString();
        const qty = Number(data.quantity || 0).toFixed(8);
        return (`\u{1F7E2} ${prefix} BUY ${notif.coin}\n` +
            `Price: \u{20A9}${price}\n` +
            `Amount: \u{20A9}${amount}\n` +
            `Quantity: ${qty}\n` +
            `Time: ${time}`);
    }
    if (notif.action === 'SELL') {
        const lines = [`\u{1F534} ${prefix} SELL ${notif.coin}`];
        if (data.entry_price && data.exit_price) {
            const entry = Number(data.entry_price).toLocaleString();
            const exit = Number(data.exit_price).toLocaleString();
            lines.push(`Entry: \u{20A9}${entry} \u{2192} Exit: \u{20A9}${exit}`);
        }
        else {
            lines.push(`Price: \u{20A9}${Number(data.price || 0).toLocaleString()}`);
        }
        if (data.pnl_krw !== undefined && data.pnl_pct !== undefined) {
            const pnlKrw = Number(data.pnl_krw).toLocaleString();
            const pnlPct = Number(data.pnl_pct).toFixed(2);
            lines.push(`P&L: \u{20A9}${pnlKrw} (${pnlPct}%)`);
        }
        if (data.fee_krw !== undefined) {
            lines.push(`Fee: \u{20A9}${Number(data.fee_krw).toLocaleString()}`);
        }
        if (data.est_krw !== undefined) {
            lines.push(`Est: \u{20A9}${Number(data.est_krw).toLocaleString()}`);
        }
        const qty = Number(data.quantity || 0).toFixed(8);
        lines.push(`Quantity: ${qty}`);
        lines.push(`Time: ${time}`);
        return lines.join('\n');
    }
    return `${prefix} ${notif.action} ${notif.coin}`;
}
async function pollTradeNotifications() {
    try {
        const resp = await fetch(`${BACKEND_URL}/api/autotrading/notifications`);
        if (!resp.ok)
            return;
        const { notifications } = await resp.json();
        if (!notifications || notifications.length === 0)
            return;
        const config = await fetchSettings();
        const ackedIds = [];
        for (const notif of notifications) {
            const message = formatTradeNotification(notif);
            let sent = false;
            if (config.whatsapp?.enabled && (0, whatsapp_1.getWhatsAppStatus)() === 'connected') {
                if (await (0, whatsapp_1.sendWhatsAppMessage)(message))
                    sent = true;
            }
            if (config.telegram?.enabled && (0, telegram_1.getTelegramStatus)() === 'connected') {
                if (await (0, telegram_1.sendTelegramMessage)(message))
                    sent = true;
            }
            if (config.matrix?.enabled && (0, matrix_1.getMatrixStatus)() === 'connected') {
                if (await (0, matrix_1.sendMatrixMessage)(message))
                    sent = true;
            }
            if (config.slack?.enabled && (0, slack_1.getSlackStatus)() === 'connected') {
                if (await (0, slack_1.sendSlackMessage)(message))
                    sent = true;
            }
            if (config.discord?.enabled && getDiscordStatus() === 'connected') {
                if (await sendDiscordMessage(message))
                    sent = true;
            }
            if (sent) {
                ackedIds.push(notif.id);
                mainWindow?.webContents.send('autotrading:notification-sent', {
                    action: notif.action,
                    coin: notif.coin,
                    source: notif.source,
                });
            }
        }
        if (ackedIds.length > 0) {
            await fetch(`${BACKEND_URL}/api/autotrading/notifications/ack`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ids: ackedIds }),
            });
            console.log(`[AutoTrading] Sent ${ackedIds.length} trade notification(s) to chat apps`);
        }
    }
    catch {
        // Silent fail — backend may not be ready yet
    }
}
function startTradeNotificationPolling() {
    if (tradePollTimer)
        return;
    tradePollTimer = setInterval(pollTradeNotifications, TRADE_POLL_INTERVAL);
    pollTradeNotifications();
    console.log('[AutoTrading] Trade notification polling started (10s interval)');
}
function stopTradeNotificationPolling() {
    if (tradePollTimer) {
        clearInterval(tradePollTimer);
        tradePollTimer = null;
    }
}
function createTray() {
    const trayIconPath = isDev
        ? path_1.default.join(__dirname, '..', 'assets', 'icon.ico')
        : path_1.default.join(process.resourcesPath, 'assets', 'icon.ico');
    const trayImage = electron_1.nativeImage.createFromPath(trayIconPath).resize({ width: 16, height: 16 });
    tray = new electron_1.Tray(trayImage);
    tray.setToolTip(`Sancho v${getDisplayVersion()}`);
    const trayMenu = electron_1.Menu.buildFromTemplate([
        {
            label: `Sancho v${getDisplayVersion()}`,
            enabled: false,
        },
        { type: 'separator' },
        {
            label: 'Show',
            click: () => {
                mainWindow?.show();
                mainWindow?.focus();
            },
        },
        {
            label: 'Auto Start',
            type: 'checkbox',
            checked: electron_1.app.getLoginItemSettings().openAtLogin,
            click: (menuItem) => {
                electron_1.app.setLoginItemSettings({ openAtLogin: menuItem.checked });
            },
        },
        { type: 'separator' },
        {
            label: 'Quit',
            click: () => {
                isQuitting = true;
                electron_1.app.quit();
            },
        },
    ]);
    tray.setContextMenu(trayMenu);
    tray.on('double-click', () => {
        mainWindow?.show();
        mainWindow?.focus();
    });
}
electron_1.app.whenReady().then(async () => {
    // Enable auto-start by default on first run (production only)
    if (!isDev) {
        const loginSettings = electron_1.app.getLoginItemSettings();
        if (!loginSettings.openAtLogin) {
            electron_1.app.setLoginItemSettings({ openAtLogin: true });
        }
    }
    await startBackend();
    createWindow();
    createTray();
    const menuTemplate = [
        {
            label: 'File',
            submenu: [
                { role: 'quit' },
            ],
        },
        {
            label: 'Edit',
            submenu: [
                { role: 'undo' },
                { role: 'redo' },
                { type: 'separator' },
                { role: 'cut' },
                { role: 'copy' },
                { role: 'paste' },
                { role: 'selectAll' },
            ],
        },
        {
            label: 'View',
            submenu: [
                { role: 'reload' },
                { role: 'forceReload' },
                { role: 'toggleDevTools' },
                { type: 'separator' },
                { role: 'resetZoom' },
                { role: 'zoomIn' },
                { role: 'zoomOut' },
                { type: 'separator' },
                { role: 'togglefullscreen' },
            ],
        },
        {
            label: 'Help',
            submenu: [
                {
                    label: `Sancho v${getDisplayVersion()}`,
                    enabled: false,
                },
                { type: 'separator' },
                {
                    label: 'About Sancho',
                    click: () => {
                        electron_1.dialog.showMessageBox({
                            type: 'info',
                            title: 'About Sancho',
                            message: `Sancho v${getDisplayVersion()}`,
                            detail: 'Windows AI Agent Desktop App\n\nhttps://github.com/jihan972025/sancho',
                        });
                    },
                },
            ],
        },
    ];
    const menu = electron_1.Menu.buildFromTemplate(menuTemplate);
    electron_1.Menu.setApplicationMenu(menu);
    if (mainWindow) {
        (0, whatsapp_1.initWhatsApp)(mainWindow);
        (0, telegram_1.initTelegram)(mainWindow);
        (0, matrix_1.initMatrix)(mainWindow);
        (0, slack_1.initSlack)(mainWindow);
        initDiscord(mainWindow);
        // Auto-connect chat apps after renderer is ready (so IPC listeners are registered)
        mainWindow.webContents.on('did-finish-load', () => {
            autoConnectChatApps();
            startNotificationPolling();
            startTradeNotificationPolling();
        });
        // Start periodic update checks
        (0, updater_1.startPeriodicCheck)(mainWindow);
    }
    electron_1.app.on('activate', () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});
electron_1.app.on('window-all-closed', () => {
    // Do not quit — keep running in tray
});
electron_1.app.on('before-quit', () => {
    isQuitting = true;
    (0, updater_1.stopPeriodicCheck)();
    stopNotificationPolling();
    stopTradeNotificationPolling();
    (0, tunnel_1.stopTunnel)();
    stopBackend();
    tray?.destroy();
    tray = null;
});
// IPC handlers
electron_1.ipcMain.handle('get-app-path', () => electron_1.app.getAppPath());
electron_1.ipcMain.handle('is-dev', () => isDev);
electron_1.ipcMain.handle('set-selected-model', (_event, model) => (0, selectedModel_1.setSelectedModel)(model));
// WhatsApp IPC handlers
electron_1.ipcMain.handle('whatsapp:connect', (_event, waVersion) => (0, whatsapp_1.connectWhatsApp)(waVersion));
electron_1.ipcMain.handle('whatsapp:disconnect', () => (0, whatsapp_1.disconnectWhatsApp)());
electron_1.ipcMain.handle('whatsapp:status', () => (0, whatsapp_1.getWhatsAppStatus)());
// Telegram IPC handlers
electron_1.ipcMain.handle('telegram:connect', (_event, apiId, apiHash) => (0, telegram_1.connectTelegram)(apiId, apiHash));
electron_1.ipcMain.handle('telegram:disconnect', () => (0, telegram_1.disconnectTelegram)());
electron_1.ipcMain.handle('telegram:status', () => (0, telegram_1.getTelegramStatus)());
// Matrix IPC handlers
electron_1.ipcMain.handle('matrix:connect', (_event, homeserverUrl, userId, password, accessToken) => (0, matrix_1.connectMatrix)(homeserverUrl, userId, password, accessToken));
electron_1.ipcMain.handle('matrix:disconnect', () => (0, matrix_1.disconnectMatrix)());
electron_1.ipcMain.handle('matrix:status', () => (0, matrix_1.getMatrixStatus)());
// Slack IPC handlers
electron_1.ipcMain.handle('slack:connect', (_event, botToken, appToken) => (0, slack_1.connectSlack)(botToken, appToken));
electron_1.ipcMain.handle('slack:disconnect', () => (0, slack_1.disconnectSlack)());
electron_1.ipcMain.handle('slack:status', () => (0, slack_1.getSlackStatus)());
// Discord IPC handlers
electron_1.ipcMain.handle('discord:connect', (_event, botToken) => connectDiscord(botToken));
electron_1.ipcMain.handle('discord:disconnect', () => disconnectDiscord());
electron_1.ipcMain.handle('discord:status', () => getDiscordStatus());
// Patch updater IPC handlers
electron_1.ipcMain.handle('patch:check', async () => {
    return (0, updater_1.checkForUpdate)();
});
electron_1.ipcMain.handle('patch:apply', async () => {
    const result = await (0, updater_1.applyPatch)((percent, channel) => {
        mainWindow?.webContents.send('patch:progress', { percent, channel });
    });
    if (result.success) {
        mainWindow?.webContents.send('patch:applied');
    }
    return result;
});
electron_1.ipcMain.handle('patch:dismiss', (_event, version) => {
    (0, updater_1.dismissUpdate)(version);
});
electron_1.ipcMain.handle('patch:restart', () => {
    electron_1.app.relaunch();
    electron_1.app.exit(0);
});
// Google OAuth IPC handlers
electron_1.ipcMain.handle('google-auth:login', async () => {
    return (0, googleAuth_1.startGoogleOAuth)();
});
electron_1.ipcMain.handle('google-auth:status', async () => {
    const http = await Promise.resolve().then(() => __importStar(require('http')));
    const data = await new Promise((resolve, reject) => {
        http.get('http://127.0.0.1:8765/api/auth/google/status', (res) => {
            let body = '';
            res.on('data', (chunk) => { body += chunk.toString(); });
            res.on('end', () => resolve(body));
            res.on('error', reject);
        }).on('error', reject);
    });
    return JSON.parse(data);
});
// Tunnel IPC handlers
electron_1.ipcMain.handle('tunnel:start', async () => {
    try {
        const url = await (0, tunnel_1.startTunnel)();
        return { url, error: '' };
    }
    catch (err) {
        const msg = err.message;
        console.error('[Tunnel] Start failed:', msg);
        return { url: '', error: msg };
    }
});
electron_1.ipcMain.handle('tunnel:stop', async () => (0, tunnel_1.stopTunnel)());
electron_1.ipcMain.handle('tunnel:status', () => (0, tunnel_1.getTunnelUrl)());
electron_1.ipcMain.handle('google-auth:logout', async () => {
    const http = await Promise.resolve().then(() => __importStar(require('http')));
    await new Promise((resolve, reject) => {
        const req = http.request('http://127.0.0.1:8765/api/auth/google/logout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
        }, (res) => {
            res.on('data', () => { });
            res.on('end', () => resolve());
            res.on('error', reject);
        });
        req.on('error', reject);
        req.end();
    });
});
// Outlook OAuth IPC handlers
electron_1.ipcMain.handle('outlook-auth:login', async (_event, clientId, clientSecret) => {
    return (0, outlookAuth_1.startOutlookOAuth)(clientId, clientSecret);
});
electron_1.ipcMain.handle('outlook-auth:status', async () => {
    const http = await Promise.resolve().then(() => __importStar(require('http')));
    const data = await new Promise((resolve, reject) => {
        http.get('http://127.0.0.1:8765/api/auth/outlook/status', (res) => {
            let body = '';
            res.on('data', (chunk) => { body += chunk.toString(); });
            res.on('end', () => resolve(body));
            res.on('error', reject);
        }).on('error', reject);
    });
    return JSON.parse(data);
});
electron_1.ipcMain.handle('outlook-auth:logout', async () => {
    const http = await Promise.resolve().then(() => __importStar(require('http')));
    await new Promise((resolve, reject) => {
        const req = http.request('http://127.0.0.1:8765/api/auth/outlook/logout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
        }, (res) => {
            res.on('data', () => { });
            res.on('end', () => resolve());
            res.on('error', reject);
        });
        req.on('error', reject);
        req.end();
    });
});
